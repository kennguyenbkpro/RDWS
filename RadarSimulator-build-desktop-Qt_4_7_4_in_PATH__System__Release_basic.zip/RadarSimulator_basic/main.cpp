#include <QtGui/QApplication>
#include "mainwindow.h"
#include <fullwindow.h>

bool rendered = true;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    FullWindow window;
    window.show();

    return a.exec();
}

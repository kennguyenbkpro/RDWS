#ifndef CONFIG_H
#define CONFIG_H

class Config
{
public:
    static const int realRaySize = 3000; //pixel
    static const int realDistance = 360; //km
};

#endif // CONFIG_H

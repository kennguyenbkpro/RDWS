#ifndef DCOMMON_H
#define DCOMMON_H

#include <QStringList>

class DCommon
{
public:
    DCommon();

    // static function

    // print QStringList to deBug console
    static void printLayerList(const QStringList & list);



};

#endif // DCOMMON_H
